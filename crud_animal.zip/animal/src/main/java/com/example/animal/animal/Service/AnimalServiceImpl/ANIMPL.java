package com.example.animal.animal.Service.AnimalServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.animal.animal.Entity.Animal;
import com.example.animal.animal.Repository.AnimalRepo;
import com.example.animal.animal.Service.AnimalService;

@Service
public class ANIMPL   implements AnimalService{



    @Autowired
    private AnimalRepo repo;
    @Override
    public Animal BuscarAnimal(int id) {
        
        return this.repo.findById(id).get();
    }

    @Override
    public Animal CrearAnimal(Animal animal) {
        
        return this.repo.save(animal);
    }

    @Override
    public void EliminarAnimal(int id) {
        
        this.repo.deleteById(id);
    }

    @Override
    public List<Animal> consultarAnimal() {
       
        return (List<Animal>) this.repo.findAll();
    }

    @Override
    public Animal modificarAnimal(Animal animal) {
        
        return this.repo.save(animal);
    }

 

}
