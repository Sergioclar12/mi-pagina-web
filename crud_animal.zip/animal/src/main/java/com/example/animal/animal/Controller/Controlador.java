package com.example.animal.animal.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.animal.animal.Entity.Animal;
import com.example.animal.animal.Service.AnimalServiceImpl.ANIMPL;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("CRUDRepo")

public class Controlador {
 
   @Autowired

   private ANIMPL impl;
     

@GetMapping
@RequestMapping(value =  "ConsultarAnimales", method = RequestMethod.GET)
    public ResponseEntity<?> ConsultarAnimales() {
    List <Animal> ListaAnimal=this.impl.consultarAnimal();
    return ResponseEntity.ok(ListaAnimal);

    }
    @PostMapping
    @RequestMapping(value = "CrearAnimal", method = RequestMethod.POST)
    public ResponseEntity<?> CrearAnimales(@RequestBody Animal animal) {
        Animal AnimalCreado=this.impl.CrearAnimal(animal);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(AnimalCreado);

}
@PutMapping
    @RequestMapping(value = "ModificarAnimales", method = RequestMethod.PUT)
    public ResponseEntity<?> ModificarAnimales(@RequestBody Animal animal) {
        Animal AnimalModificado=this.impl.modificarAnimal(animal);

        return ResponseEntity.status(HttpStatus.CREATED).body(AnimalModificado);
    }

    @GetMapping
    @RequestMapping(value = "BuscarAnimal/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> BuscarAnimal(@PathVariable int id) {
        Animal animal=this.impl.BuscarAnimal(id);

        return ResponseEntity.ok(animal);
    

    }

    @DeleteMapping
    @RequestMapping(value = "EliminarAnimales/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> EliminarAnimales(@PathVariable int id) {
        this.impl.EliminarAnimal(id);
        
        return ResponseEntity.ok().build();


}
}
