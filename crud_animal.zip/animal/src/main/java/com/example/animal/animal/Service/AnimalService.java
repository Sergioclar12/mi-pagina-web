package com.example.animal.animal.Service;

import java.util.List;

import com.example.animal.animal.Entity.Animal;


public interface AnimalService {

    public List<Animal> consultarAnimal();

    public Animal CrearAnimal(Animal animal);
    
    public Animal modificarAnimal(Animal animal);
    
    public Animal BuscarAnimal (int id);
    
    public void EliminarAnimal(int id);
}
