package com.example.animal.animal.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.animal.animal.Entity.Animal;

public interface AnimalRepo extends CrudRepository<Animal,Integer>{

}
