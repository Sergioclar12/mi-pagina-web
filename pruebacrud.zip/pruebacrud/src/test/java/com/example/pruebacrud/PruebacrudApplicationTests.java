package com.example.pruebacrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebacrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
