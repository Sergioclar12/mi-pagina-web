package com.example.pruebacrud.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.pruebacrud.Entity.Persona;

public interface PersonaRepo extends CrudRepository<Persona,Integer> {

}
