package com.example.pruebacrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebacrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebacrudApplication.class, args);
	}

}
