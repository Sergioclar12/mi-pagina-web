package com.example.pruebacrud.Service.PersonaServiceIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pruebacrud.Entity.Persona;
import com.example.pruebacrud.Repository.PersonaRepo;
import com.example.pruebacrud.Service.PersonaService;

@Service
public class PSIMPL implements PersonaService {



@Autowired
    private PersonaRepo repo;
    @Override
    public Persona BuscarPersona(int id) {
        
        return this.repo.findById(id).get();
    }

    @Override
    public Persona CrearPersona(Persona persona) {
        
        return this.repo.save(persona);
    }

    @Override
    public void EliminarPersona(int id) {
        
        this.repo.deleteById(id);
    }

    @Override
    public List<Persona> consultarPersona() {
       
        return (List<Persona>) this.repo.findAll();
    }

    @Override
    public Persona modificarPersona(Persona persona) {
        
        return this.repo.save(persona);
    }

 

 

}
