package com.example.pruebacrud.Service;

import java.util.List;

import com.example.pruebacrud.Entity.Persona;

public interface PersonaService {

public List<Persona> consultarPersona();

public Persona CrearPersona(Persona persona);

public Persona modificarPersona(Persona persona);

public Persona BuscarPersona (int id);

public void EliminarPersona(int id);




}
